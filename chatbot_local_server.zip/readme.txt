
📦 LOKALER CHATBOT SERVER – ANLEITUNG

1. ✅ Voraussetzungen:
   - Python 3 muss auf deinem PC installiert sein
   - Alle Geräte müssen im selben WLAN sein

2. 📁 Dateien entpacken

3. 🖥️ Server starten:
   - Öffne CMD oder Terminal
   - Wechsle in den entpackten Ordner
     Beispiel:
       cd Desktop/chatbot_local_server
   - Starte den Server:
       python -m http.server 8000

4. 📱 IP-Adresse finden:
   - Gib in CMD ein:
       ipconfig
   - Merke dir die IPv4-Adresse (z. B. 192.168.0.42)

5. 📲 Auf Handys im Browser öffnen:
   http://[deine-ip]:8000
   Beispiel:
   http://192.168.0.42:8000

6. 🧪 Testen:
   - Öffne die Login-Seite (index.html)
   - Logge dich mit Passwort ein:
     - Admin: 0612
     - Spieler: 1 bis 7

Viel Spaß!
